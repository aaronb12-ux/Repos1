#ifndef INPUTVAL_H
    #define INPUTVAL_H
bool isValidFormat(const int numArgsRead, const int numArgsNeed);
int getValidInt(int num_cols);


#endif