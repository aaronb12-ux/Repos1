
#ifndef GAMEBOARD_H
    #define GAMEBOARD_H
    char** make_grid(int num_rows, int num_cols);
    void printboard(char** board, int num_rows, int num_cols, int num_row_for_grid);
     
#endif 
 